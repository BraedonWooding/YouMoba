﻿using UnityEngine;
using System.Collections;

//Made by Braedon (Shadow Fang Realm)
//This code can only be used for private use
[System.Serializable]
public class EmptyItem : Item {


    public EmptyItem()
    {
        itemID = -1;
    }
}
