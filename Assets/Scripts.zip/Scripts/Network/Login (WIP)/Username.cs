﻿using UnityEngine;
using System.Collections;

//Made by Braedon (Shadow Fang Realm)
//This code can only be used for private use
public class Username : MonoBehaviour
{
		public static string username;

		public void ClickedLoginButton ()
		{
				username = GameObject.Find ("Input_Username").GetComponent<UnityEngine.UI.InputField> ().text;
				Application.LoadLevel (1);
		}
}