﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.UI;

//Made by Braedon (Shadow Fang Realm)
//This code can only be used for private use
public class MainNetwork : MonoBehaviour
{

		public NetworkView nView;
		string ipAddress;
		private List<string> ID = new List<string> ();
		const int numberOfPlayersMax = 4;
		public string playerID;
		static bool inGame;
		public InputField input_Password;
		public InputField input_IP;
		GameObject canvas_StartingMenu;
		GameObject canvas_ChampSelect;
		public string playerUsername;
		public GameObject prefab_PlayerYellow;
		public GameObject prefab_PlayerGreen;
		public GameObject panel_GreenSide;
		public GameObject panel_YellowSide;

		void Start ()
		{
				Application.runInBackground = true;
				ipAddress = Network.player.ipAddress;
				nView = GetComponent<NetworkView> ();
				input_IP = GameObject.Find ("Input_Ip").GetComponent<InputField> ();
				input_Password = GameObject.Find ("Input_Password").GetComponent<InputField> ();
				DontDestroyOnLoad (this);
				input_IP.ActivateInputField ();
				input_IP.text = ipAddress;
				input_IP.DeactivateInputField ();
				canvas_ChampSelect = GameObject.Find ("Canvas_ChampSelect");
				canvas_StartingMenu = GameObject.Find ("Canvas_StartingMenu");
				panel_YellowSide = GameObject.Find ("Side_0");
				panel_GreenSide = GameObject.Find ("Side_1");
				canvas_ChampSelect.SetActive (false);
				playerUsername = Username.username;
		}

		public void LaunchServer ()
		{
				Network.incomingPassword = input_Password.text;
				bool useNat = !Network.HavePublicAddress ();
				Network.InitializeServer (numberOfPlayersMax, 25000, useNat);
				playerID = Network.player.guid;
				ID.Add (Network.player.guid);
		}
	
		public void JoinServer ()
		{
				Network.Connect (input_IP.text, 25000, input_Password.text);
				playerID = Network.player.guid;
				
		}

		void OnPlayerConnected (NetworkPlayer player)
		{
				ID.Add (player.guid);
				ChampionSelection ();
		}
	
		void OnPlayerDisconnected (NetworkPlayer player)
		{
				Network.RemoveRPCs (player);
				Network.DestroyPlayerObjects (player);
				ID.Remove (player.guid);
		}
	
		void OnApplicationQuit ()
		{
				Network.Disconnect ();
		}

		void ChampionSelection ()
		{
				canvas_ChampSelect.SetActive (true);
				Debug.Log (Network.peerType);
				if (Network.peerType == NetworkPeerType.Server) {
						nView.RPC ("TurnObjectOnOff", RPCMode.AllBuffered, true);
						for (int i = 0; i < ID.Count; i++) {
								if (i % 2 == 0) {
										nView.RPC ("SpawnChampSelectPlayer", RPCMode.AllBuffered, true, panel_GreenSide.name, ID [i]);
								} else {
										nView.RPC ("SpawnChampSelectPlayer", RPCMode.AllBuffered, false, panel_YellowSide.name, ID [i]);
								}		
						}
				}
		}

		void StartGame ()
		{
				
		}

		[RPC]

		void SpawnChampSelectPlayer (bool greenOrYellow, string location, string ID)
		{
				GameObject go;
				if (greenOrYellow) {
						go = (GameObject)Instantiate (prefab_PlayerGreen);
				} else {
						go = (GameObject)Instantiate (prefab_PlayerYellow);
				}
				go.transform.SetParent (GameObject.Find (location).transform);
		
		}

		[RPC]

		void TurnObjectOnOff (bool newState)
		{
				canvas_ChampSelect.SetActive (newState);
		}
}