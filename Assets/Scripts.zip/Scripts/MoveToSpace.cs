﻿using UnityEngine;
using System.Collections;

//Made by Braedon (Shadow Fang Realm)
//This code can only be used for private use
public class MoveToSpace : MonoBehaviour
{
		public Vector3 newPos;
		public float moveSpeed = 10f;
		public Camera cam;
		public Transform trans;

		void Start ()
		{
				newPos = this.transform.position;
		}

		void Update ()
		{

				if (Input.GetMouseButtonDown (0) && !UnityEngine.EventSystems.EventSystem.current.IsPointerOverGameObject ()) {

						Ray ray = Camera.main.ScreenPointToRay (Input.mousePosition);
						RaycastHit hit;

						if (Physics.Raycast (ray, out hit, 10000)) {
								if (!hit.transform.name.Equals ("Unit Model")) {
										Debug.Log (hit.transform.name);
										newPos = hit.point;
								}
						}
				}
				if (newPos != this.transform.position) {
						transform.position = Vector3.MoveTowards (this.transform.position, new Vector3 (newPos.x, transform.position.y, newPos.z), moveSpeed * Time.deltaTime);
				}
		}
}