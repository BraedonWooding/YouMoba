﻿using UnityEngine;
using System.Collections;

//Made by Braedon (Shadow Fang Realm)
//This code can only be used for private use
[System.Serializable]
public class Effect
{
		public float duration, maxDuration;
		public string user;

		public virtual void EffectActivate ()
		{
		}
}