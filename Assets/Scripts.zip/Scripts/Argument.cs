﻿using UnityEngine;
using System.Collections;

//Made by Braedon (Shadow Fang Realm)
//This code can only be used for private use
[System.Serializable]
public class Argument
{

		public float Amount;
		public string sign;
		public Sprite signs;
		public bool and;
		public int andV;

		private Argument ()
		{
		}
}