All scripts, textures and everything excluding the plugins to be 
used under fair use and private use only.

Hayden Studios: A huge amount of the textures and models.
Braedon (Shadow Fang Realm): All scripts (excluding plugins) all scenes and the terrain.